import React, { useState, useEffect } from 'react';
import { BookOpen, Code, GraduationCap, Plus, Save, RefreshCw, Trash2, Linkedin, Globe2, School, FileText } from 'lucide-react';
import Prism from 'prismjs';
import 'prismjs/themes/prism-tomorrow.css';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-jsx';
import 'prismjs/components/prism-tsx';
import 'prismjs/components/prism-python';

interface AlumniProfile {
  name: string;
  linkedin: string;
  role: string;
}

interface UniversityData {
  [key: string]: {
    name: string;
    alumni: AlumniProfile[];
  };
}

interface Opportunity {
  title: string;
  organization: string;
  link: string;
  deadline?: string;
  description: string;
}

interface CountryOpportunities {
  [key: string]: {
    internships: Opportunity[];
    scholarships: Opportunity[];
  };
}

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [selectedUniversity, setSelectedUniversity] = useState('nust');
  const [selectedCountry, setSelectedCountry] = useState('usa');
  const [timetableData, setTimetableData] = useState<string[][]>([['9:00 AM', '', '', '', '', '']]);
  const [codeInput, setCodeInput] = useState('// Enter your code here');
  const [debugOutput, setDebugOutput] = useState('');
  const [grammarText, setGrammarText] = useState('');
  const [grammarAnalysis, setGrammarAnalysis] = useState('');
  const [codeLanguage, setCodeLanguage] = useState('javascript');

  const opportunities: CountryOpportunities = {
    usa: {
      internships: [
        {
          title: "Research Internship Opportunities 2025",
          organization: "Various Research Institutions",
          link: "https://github.com/Gaurav2543/Research-Internship-Opportunities-2025",
          deadline: "2024-12-31",
          description: "Curated list of research internship opportunities in Bioinformatics and Computer Science domains"
        }
      ],
      scholarships: [
        {
          title: "GitHub Scholarships Collection",
          organization: "GitHub Community",
          link: "https://github.com/topics/scholarships",
          deadline: "Various",
          description: "Comprehensive collection of scholarship opportunities from the GitHub community"
        }
      ]
    }
  };

  const universities: UniversityData = {
    nust: {
      name: 'NUST',
      alumni: [
        { name: 'Sarah Ahmed', role: 'Senior Software Engineer at Google', linkedin: 'https://linkedin.com/in/sarah-ahmed' },
        { name: 'Ali Hassan', role: 'Data Scientist at Microsoft', linkedin: 'https://linkedin.com/in/ali-hassan' },
        { name: 'Zara Malik', role: 'Product Manager at Amazon', linkedin: 'https://linkedin.com/in/zara-malik' },
        { name: 'Ibrahim Khan', role: 'AI Research Engineer at DeepMind', linkedin: 'https://linkedin.com/in/ibrahim-khan' },
        { name: 'Ayesha Tariq', role: 'Technical Lead at Uber', linkedin: 'https://linkedin.com/in/ayesha-tariq' }
      ]
    },
    fast: {
      name: 'FAST',
      alumni: [
        { name: 'Fatima Khan', role: 'Senior Product Manager at Amazon', linkedin: 'https://linkedin.com/in/fatima-khan' },
        { name: 'Omar Malik', role: 'Full Stack Developer at Meta', linkedin: 'https://linkedin.com/in/omar-malik' },
        { name: 'Hira Naveed', role: 'Cloud Architect at AWS', linkedin: 'https://linkedin.com/in/hira-naveed' },
        { name: 'Saad Ahmed', role: 'Machine Learning Engineer at Netflix', linkedin: 'https://linkedin.com/in/saad-ahmed' },
        { name: 'Maham Zaidi', role: 'Security Engineer at Microsoft', linkedin: 'https://linkedin.com/in/maham-zaidi' }
      ]
    },
    gik: {
      name: 'GIK',
      alumni: [
        { name: 'Zainab Ali', role: 'ML Engineer at Apple', linkedin: 'https://linkedin.com/in/zainab-ali' },
        { name: 'Hassan Syed', role: 'DevOps Engineer at Netflix', linkedin: 'https://linkedin.com/in/hassan-syed' },
        { name: 'Amir Khan', role: 'Robotics Engineer at Boston Dynamics', linkedin: 'https://linkedin.com/in/amir-khan' },
        { name: 'Sana Malik', role: 'Software Architect at LinkedIn', linkedin: 'https://linkedin.com/in/sana-malik' },
        { name: 'Bilal Ahmed', role: 'Quantum Computing Researcher at IBM', linkedin: 'https://linkedin.com/in/bilal-ahmed' }
      ]
    },
    uet: {
      name: 'UET',
      alumni: [
        { name: 'Amna Khalid', role: 'Systems Architect at IBM', linkedin: 'https://linkedin.com/in/amna-khalid' },
        { name: 'Usman Ahmed', role: 'Cloud Engineer at Oracle', linkedin: 'https://linkedin.com/in/usman-ahmed' },
        { name: 'Nadia Hassan', role: 'Backend Engineer at Stripe', linkedin: 'https://linkedin.com/in/nadia-hassan' },
        { name: 'Kamran Ali', role: 'AR/VR Developer at Unity', linkedin: 'https://linkedin.com/in/kamran-ali' },
        { name: 'Rabia Malik', role: 'Blockchain Developer at Coinbase', linkedin: 'https://linkedin.com/in/rabia-malik' }
      ]
    }
  };

  useEffect(() => {
    const savedTimetable = localStorage.getItem('timetable');
    if (savedTimetable) {
      setTimetableData(JSON.parse(savedTimetable));
    }
  }, []);

  const addRow = () => {
    const lastTime = timetableData[timetableData.length - 1][0];
    let newTime = '9:00 AM';
    
    if (lastTime) {
      const hour = parseInt(lastTime.split(':')[0]);
      const period = lastTime.includes('PM') ? 'PM' : 'AM';
      let newHour = hour + 1;
      let newPeriod = period;
      
      if (hour === 11) {
        newHour = 12;
        newPeriod = period === 'AM' ? 'PM' : 'AM';
      } else if (hour === 12) {
        newHour = 1;
      }
      
      newTime = `${newHour}:00 ${newPeriod}`;
    }
    
    setTimetableData([...timetableData, [newTime, '', '', '', '', '']]);
  };

  const addColumn = () => {
    setTimetableData(timetableData.map(row => [...row, '']));
  };

  const updateCell = (rowIndex: number, colIndex: number, value: string) => {
    const newData = timetableData.map((row, i) =>
      i === rowIndex ? row.map((cell, j) => j === colIndex ? value : cell) : row
    );
    setTimetableData(newData);
  };

  const saveTimetable = () => {
    localStorage.setItem('timetable', JSON.stringify(timetableData));
    alert('Timetable saved!');
  };

  const loadTimetable = () => {
    const savedTimetable = localStorage.getItem('timetable');
    if (savedTimetable) {
      setTimetableData(JSON.parse(savedTimetable));
      alert('Timetable loaded!');
    } else {
      alert('No saved timetable found.');
    }
  };

  const clearTimetable = () => {
    if (confirm('Are you sure you want to clear the timetable?')) {
      setTimetableData(timetableData.map(row => row.map((_, i) => i === 0 ? row[0] : '')));
    }
  };

  const debugCode = () => {
    try {
      let language = codeLanguage;
      const analysis = [];
      
      // Language-specific analysis
      if (language === 'python') {
        // Python-specific checks
        if (!codeInput.startsWith('def ') && !codeInput.startsWith('class ') && codeInput.includes('def ')) {
          analysis.push('⚠️ Function definition should be at module level');
        }
        if (codeInput.includes('print ')) {
          analysis.push('⚠️ Use print() instead of print statement');
        }
        if (codeInput.includes('except:')) {
          analysis.push('⚠️ Avoid bare except clause');
        }
        if (codeInput.includes('import *')) {
          analysis.push('⚠️ Avoid wildcard imports');
        }
        
        // Check for indentation issues
        const lines = codeInput.split('\n');
        lines.forEach((line, index) => {
          if (line.startsWith(' ') && line.length > 0 && line.indexOf(' ') % 4 !== 0) {
            analysis.push(`⚠️ Line ${index + 1}: Inconsistent indentation. Use 4 spaces.`);
          }
        });
        
        // Check for missing colons
        lines.forEach((line, index) => {
          if ((line.includes('def ') || line.includes('class ') || line.includes('if ') || 
               line.includes('else') || line.includes('elif ') || line.includes('for ') || 
               line.includes('while ')) && !line.includes(':')) {
            analysis.push(`⚠️ Line ${index + 1}: Missing colon`);
          }
        });
      } else {
        // JavaScript checks
        if (codeInput.includes('console.log')) {
          analysis.push('⚠️ Debug statements found');
        }
        if (codeInput.includes('var ')) {
          analysis.push('⚠️ Consider using let/const instead of var');
        }
        if (codeInput.includes('==')) {
          analysis.push('⚠️ Consider using strict equality (===)');
        }
      }

      // Syntax highlighting
      const highlighted = Prism.highlight(
        codeInput,
        Prism.languages[language],
        language
      );
      
      setDebugOutput(`
        <div class="mb-4">
          <pre><code class="language-${language}">${highlighted}</code></pre>
        </div>
        <div class="text-orange-500">
          ${analysis.length ? analysis.join('<br>') : '✅ No issues found'}
        </div>
      `);
    } catch (error) {
      setDebugOutput(`Error: ${error.message}`);
    }
  };

  const analyzeGrammar = () => {
    const sentences = grammarText.split(/[.!?]+/).filter(Boolean);
    const words = grammarText.split(/\s+/).filter(Boolean);
    const analysis = [];
    
    // Common grammar mistakes
    const commonErrors = {
      "your": "you're",
      "youre": "you're",
      "its": "it's",
      "their": "they're",
      "theyre": "they're",
      "whose": "who's",
      "affect": "effect",
      "accept": "except",
      "alot": "a lot",
      "could of": "could have",
      "should of": "should have",
      "would of": "would have",
      "loose": "lose",
      "then": "than",
      "to": "too",
      "weather": "whether",
      "were": "we're",
      "whose": "who's"
    };

    // Check for common grammar mistakes
    Object.entries(commonErrors).forEach(([error, correction]) => {
      const regex = new RegExp(`\\b${error}\\b`, 'gi');
      if (grammarText.match(regex)) {
        analysis.push(`⚠️ "${error}" might be incorrect. Did you mean "${correction}"?`);
      }
    });

    // Check for repeated words
    const repeatedWords = grammarText.match(/\b(\w+)\s+\1\b/gi);
    if (repeatedWords) {
      analysis.push('⚠️ Repeated words found: ' + repeatedWords.join(', '));
    }

    // Check sentence structure
    sentences.forEach((sentence, i) => {
      const trimmedSentence = sentence.trim();
      
      // Check sentence length
      if (trimmedSentence.split(/\s+/).length > 30) {
        analysis.push(`⚠️ Sentence ${i + 1} is very long (consider breaking it up)`);
      }
      if (trimmedSentence.split(/\s+/).length < 3) {
        analysis.push(`⚠️ Sentence ${i + 1} might be too short`);
      }

      // Check for capitalization
      if (trimmedSentence.length > 0 && trimmedSentence[0] !== trimmedSentence[0].toUpperCase()) {
        analysis.push(`⚠️ Sentence ${i + 1} should start with a capital letter`);
      }

      // Check for punctuation
      if (!/[.!?]$/.test(trimmedSentence)) {
        analysis.push(`⚠️ Sentence ${i + 1} might be missing proper punctuation`);
      }
    });

    // Check for very long words
    const longWords = words.filter(word => word.length > 20);
    if (longWords.length > 0) {
      analysis.push('⚠️ Very long words detected: ' + longWords.join(', '));
    }

    // Check for numbers in sentences
    const numbersInText = grammarText.match(/\b\d+\b/g);
    if (numbersInText) {
      analysis.push('⚠️ Consider spelling out numbers less than ten in formal writing');
    }

    const stats = `
📊 Text Statistics:
• Sentences: ${sentences.length}
• Words: ${words.length}
• Average words per sentence: ${(words.length / sentences.length).toFixed(1)}
• Characters: ${grammarText.length}
• Characters (excluding spaces): ${grammarText.replace(/\s/g, '').length}

🔍 Grammar Analysis:
${analysis.length ? analysis.join('\n') : '✅ No major issues found'}
    `;
    
    setGrammarAnalysis(stats);
  };

  return (
    <div className="min-h-screen bg-black">
      <nav className="bg-orange-600 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <BookOpen className="h-8 w-8 text-white" />
              <span className="ml-2 text-white text-xl font-bold">Student Hub</span>
            </div>
            <div className="hidden md:block">
              <div className="flex items-center space-x-4">
                {['home', 'opportunities', 'universities', 'timetable', 'debugger', 'grammar'].map((section) => (
                  <button
                    key={section}
                    onClick={() => setActiveSection(section)}
                    className={`px-3 py-2 rounded-md text-sm font-medium ${
                      activeSection === section
                        ? 'bg-orange-700 text-white'
                        : 'text-orange-100 hover:bg-orange-500'
                    }`}
                  >
                    {section.charAt(0).toUpperCase() + section.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </nav>

      {activeSection === 'home' && (
        <div 
          className="relative bg-cover bg-center py-32"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")',
            backgroundBlendMode: 'overlay',
            backgroundColor: 'rgba(0, 0, 0, 0.6)'
          }}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl font-bold text-white mb-4">
              Welcome to Student Hub
            </h1>
            <p className="text-xl text-gray-200 mb-8">
              Your comprehensive platform for academic success and career growth
            </p>
            <button
              onClick={() => setActiveSection('opportunities')}
              className="bg-orange-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-orange-700 transition duration-300"
            >
              Explore Opportunities
            </button>
          </div>
        </div>
      )}

      {activeSection === 'opportunities' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="mb-8">
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="w-full md:w-64 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-orange-500"
            >
              {Object.keys(opportunities).map((country) => (
                <option key={country} value={country}>
                  {country.toUpperCase()}
                </option>
              ))}
            </select>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gray-900 rounded-xl shadow-md p-6 hover:shadow-lg transition duration-300">
              <h2 className="text-2xl font-bold text-orange-500 mb-4 flex items-center">
                <GraduationCap className="h-6 w-6 mr-2" />
                Internships in {selectedCountry.toUpperCase()}
              </h2>
              <ul className="space-y-4">
                {opportunities[selectedCountry].internships.map((internship, index) => (
                  <li key={index} className="p-4 hover:bg-gray-800 rounded-lg border border-gray-700">
                    <h3 className="font-semibold text-lg text-white">{internship.title}</h3>
                    <p className="text-gray-400 text-sm mb-2">{internship.organization}</p>
                    <p className="text-gray-300 mb-3">{internship.description}</p>
                    {internship.deadline && (
                      <p className="text-sm text-gray-400 mb-2">Deadline: {internship.deadline}</p>
                    )}
                    <a
                      href={internship.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-orange-500 hover:text-orange-400 flex items-center group"
                    >
                      <Globe2 className="h-4 w-4 mr-2" />
                      <span className="group-hover:underline">Apply Now</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-gray-900 rounded-xl shadow-md p-6 hover:shadow-lg transition duration-300">
              <h2 className="text-2xl font-bold text-orange-500 mb-4 flex items-center">
                <School className="h-6 w-6 mr-2" />
                Scholarships in {selectedCountry.toUpperCase()}
              </h2>
              <ul className="space-y-4">
                {opportunities[selectedCountry].scholarships.map((scholarship, index) => (
                  <li key={index} className="p-4 hover:bg-gray-800 rounded-lg border border-gray-700">
                    <h3 className="font-semibold text-lg text-white">{scholarship.title}</h3>
                    <p className="text-gray-400 text-sm mb-2">{scholarship.organization}</p>
                    <p className="text-gray-300 mb-3">{scholarship.description}</p>
                    {scholarship.deadline && (
                      <p className="text-sm text-gray-400 mb-2">Deadline: {scholarship.deadline}</p>
                    )}
                    <a
                      href={scholarship.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-orange-500 hover:text-orange-400 flex items-center group"
                    >
                      <Globe2 className="h-4 w-4 mr-2" />
                      <span className="group-hover:underline">Learn More</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'universities' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-gray-900 rounded-xl shadow-md p-6">
            <div className="mb-6">
              <select
                value={selectedUniversity}
                onChange={(e) => setSelectedUniversity(e.target.value)}
                className="w-full md:w-64 px-4 py-2 rounded-lg border border-gray-700 bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                {Object.keys(universities).map((uni) => (
                  <option key={uni} value={uni}>
                    {universities[uni].name}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {universities[selectedUniversity].alumni.map((alumni, index) => (
                <div key={index} className="bg-gray-800 rounded-lg p-6 hover:bg-gray-700 transition duration-300">
                  <h3 className="text-lg font-semibold text-white mb-2">{alumni.name}</h3>
                  <p className="text-gray-300 mb-4">{alumni.role}</p>
                  <a 
                    href={alumni.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-orange-500 hover:text-orange-400 flex items-center group"
                  >
                    <Linkedin className="h-5 w-5 mr-2" />
                    <span className="group-hover:underline">View Profile</span>
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSection === 'timetable' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-gray-900 rounded-xl shadow-md p-6">
            <div className="flex flex-wrap gap-4 mb-6">
              <button
                onClick={addRow}
                className="flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Row
              </button>
              <button
                onClick={addColumn}
                className="flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Column
              </button>
              <button
                onClick={saveTimetable}
                className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <Save className="h-4 w-4 mr-2" />
                Save
              </button>
              <button
                onClick={loadTimetable}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Load
              </button>
              <button
                onClick={clearTimetable}
                className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-700">
                <thead className="bg-gray-800">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                      Time/Day
                    </th>
                    {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day) => (
                      <th
                        key={day}
                        className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider"
                      >
                        {day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-gray-900 divide-y divide-gray-700">
                  {timetableData.map((row, rowIndex) => (
                    <tr key={rowIndex}>
                      {row.map((cell, colIndex) => (
                        <td
                          key={colIndex}
                          className="px-6 py-4 whitespace-nowrap text-gray-300"
                          contentEditable={true}
                          onBlur={(e) => updateCell(rowIndex, colIndex, e.currentTarget.textContent || '')}
                          suppressContentEditableWarning={true}
                        >
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'debugger' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-gray-900 rounded-xl shadow-md p-6">
            <h2 className="text-2xl font-bold text-orange-500 mb-4 flex items-center">
              <Code className="h-6 w-6 mr-2" />
              Code Debugger
            </h2>
            <div className="mb-4">
              <select
                value={codeLanguage}
                onChange={(e) => setCodeLanguage(e.target.value)}
                className="w-full md:w-64 px-4 py-2 rounded-lg border border-gray-700 bg-gray-800 text-white focus:outline-none focus:ring-2 focus:ring-orange-500 mb-4"
              >
                <option value="javascript">JavaScript</option>
                <option value="python">Python</option>
              </select>
              <textarea
                value={codeInput}
                onChange={(e) => setCodeInput(e.target.value)}
                className="w-full h-64 p-4 bg-gray-800 text-white rounded-lg font-mono"
                placeholder={codeLanguage === 'python' ? '# Enter your Python code here' : '// Enter your JavaScript code here'}
              />
            </div>
            <button
              onClick={debugCode}
              className="mb-4 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
            >
              Analyze Code
            </button>
            <div 
              className="bg-gray-800 p-4 rounded-lg text-white"
              dangerouslySetInnerHTML={{ __html: debugOutput }}
            />
          </div>
        </div>
      )}

      {activeSection === 'grammar' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-gray-900 rounded-xl shadow-md p-6">
            <h2 className="text-2xl font-bold text-orange-500 mb-4 flex items-center">
              <FileText className="h-6 w-6 mr-2" />
              Grammar Analyzer
            </h2>
            <div className="mb-4">
              <textarea
                value={grammarText}
                onChange={(e) => setGrammarText(e.target.value)}
                placeholder="Enter your text here for grammar analysis..."
                className="w-full h-64 p-4 bg-gray-800 text-white rounded-lg"
              />
            </div>
            <button
              onClick={analyzeGrammar}
              className="mb-4 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
            >
              Analyze Text
            </button>
            <pre className="bg-gray-800 p-4 rounded-lg text-white whitespace-pre-wrap font-mono">
              {grammarAnalysis}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;